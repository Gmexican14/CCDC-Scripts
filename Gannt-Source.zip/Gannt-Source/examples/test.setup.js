// @ts-nocheck
const { setDefaultOptions } = require('expect-puppeteer');
setDefaultOptions({ timeout: 10 * 1000 });
